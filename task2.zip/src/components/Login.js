import React, { useContext } from "react";
import { LoginContext } from "../contexts/LoginContext";

function Login() {
  const { setUsername, setPassword, ShowhomePage } = useContext(LoginContext);
  return (
    <div>
      <input
        type="text"
        placeholder="enter username"
        onChange={(e) => {
          setUsername(e.target.value);
        }}
      ></input>
      <input
        typr="password"
        placeholder="enter password"
        onChange={(e) => {
          setPassword(e.target.value);
        }}
      ></input>
      <button type="submit" placeholder="submit"
          onClick={() => {
          ShowhomePage(true);
        }}
      >Submit</button>
    </div>
  );
}

export default Login;

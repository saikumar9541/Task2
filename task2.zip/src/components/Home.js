import React, { useContext , useEffect, useState} from "react";
import { LoginContext } from "../contexts/LoginContext";
import Axios from 'axios';

function Home() {
  const { username } = useContext(LoginContext);
  const [post,setPost] = useState([]);
   useEffect(()=>{
    const dataFetch = async () => {
      const data = await (
        await fetch(
          "https://newsapi.org/v2/everything?q=tesla&from=2022-11-22&sortBy=publishedAt&apiKey=213d55c353f142e48e4d928be44bc538"
        )
      ).json();
      console.log(data);
        }
        dataFetch()
        // setPost({id:data.data[0].id,title:data.data[0].title,descp:data.data[0].descp,createdby:data.data[0].createdby})
},[])
  return (
    <div className="HomePage">
        <div className="PostContainer">
                <h1>Welcome!</h1>
                <p>List Of Articles Available </p>
                {post.map((val,key)=>{
                 return(
                 <div className="post">
                     <h2>Title:{val.title}</h2>
                     <p>Author:{val.author}</p>
                     <p>Description:{val.description}</p>
                </div>
                );
            })};
        </div>
    </div>
  );
}

export default Home;
